# Multinode Sunbeam MAAS Testing with Testflinger

This is a copy from freyes PR and modified to my use case. Focus is to run with testflinger using CLI.

## How it differs from freyes PR

- not building snap, using existing snap from store
- only local Tetstflinger deployment
- not using libvirt networks because they use mode=nat which always starts a DHCP server which conflicts with MAAS DHCP server
- defning more networks and vlans to enable many network spaces

## What works

- `./local-testflinger.sh <launchpad-id>` deploys a Testflinger machine and runs terragrunt apply
  - Requires your Launchpad or GitHub ID (e.g., `lp:username` or `gh:username`)
  - MAAS is installed and configured
  - tags for Sunbeam deployment are created and assigned
- testflinger job stays in reserved state showing IP to ssh to
- ssh and running `./runit.sh` will install sunbeam snap and run the deployment

## Usage

```bash
# Deploy with your Launchpad ID
./local-testflinger.sh lp:yourusername

# Deploy with GitHub ID
./local-testflinger.sh gh:yourusername
```

## Known Issues

- currently `sunbeam cluster deploy` fails with microceph complaining it cannot find a disk
- nothing after that was tested yet
- when machines are defined they have second interface in wrong fabric, there is extra fabric created for each (6 useless fabrics which should not be there)
- there is a high chance external network will not work
- there are several more networks defined and they should be used in deployment (internal, ceph etc)

## Things to improve

- there are several null providers used which just run bunch of commands
- assigning tags to disks and NICs in MAAS is prime example of part that should be using MAAS provider properly
- it would be nicer to use libvirt provider to define networks but there was the issue with DHCP servers conflicting
- solve the issue with extra fabrics created for second nic of each node
