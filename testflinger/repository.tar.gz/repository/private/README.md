Directory to write temporary files that are private in nature, for example generated password-less ssh keys.
