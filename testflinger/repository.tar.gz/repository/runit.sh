TEST_MAAS_API_KEY="$(cat ~/api.key)" TEST_MAAS_URL=http://172.16.1.2:5240/MAAS ./test-multinode-maas.sh  2024.1/beta 3/stable

